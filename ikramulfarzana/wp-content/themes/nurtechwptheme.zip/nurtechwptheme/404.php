<?php get_header(); ?>
<section class="inner-section">
	<div class="inner-content-body">
			<article  class="page type-page status-publish hentry">
	<header class="entry-header-page">
		<h2>Page Not Found </h2>
 	</header><!-- .entry-header -->
	<div class="entry-content">
        <h1>Oops!</h1>
        <h2>404 Not Found</h2>
        <p>Sorry, an error has occured, Requested page not found</p>
	</div><!-- .entry-content -->
</article>


	</div>

</section>
<?php get_footer();
